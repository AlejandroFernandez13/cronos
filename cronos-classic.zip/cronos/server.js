const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { URL } = require('url');

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const PUBLIC = path.join(__dirname, 'public');
const songs = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'songs.json'), 'utf8'));
const songById = new Map(songs.map((s) => [s.id, s]));
const rooms = new Map();

const TURN_MS = 25000;
const THINK_MS = 15000;
const ROB_WINDOW_MS = 6000;
const ROB_THINK_MS = 10000;
const TARGET_SCORE = 20;

function id(bytes = 9) { return crypto.randomBytes(bytes).toString('base64url'); }
function roomCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code;
  do code = Array.from({length:5}, () => chars[crypto.randomInt(chars.length)]).join(''); while (rooms.has(code));
  return code;
}
function cleanName(name) { return String(name || '').trim().slice(0,18).replace(/[<>]/g,''); }
function normalize(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]/g,''); }
function player(id, name, host=false) { return { id, name, isHost:host, score:0, streak:0, robs:2, timeline:[] }; }
function orderedTimeline(p) { return [...p.timeline].sort((a,b)=>a.year-b.year || a.addedAt-b.addedAt); }
function insertCard(p, song) { p.timeline.push({id:song.id,title:song.title,artist:song.artist,year:song.year,addedAt:Date.now()+Math.random()}); p.timeline.sort((a,b)=>a.year-b.year || a.addedAt-b.addedAt); }
function buildDeck() { return songs.map(s=>s.id).sort(()=>Math.random()-0.5); }
function publicSong(song, reveal=false) { return reveal ? {...song} : {id:song.id,youtubeId:song.youtubeId,start:song.start,duration:song.duration}; }
function snapshot(room) {
  return { code:room.code, hostId:room.hostId, status:room.status, phase:room.phase, round:room.round, activePlayerId:room.activePlayerId, targetScore:TARGET_SCORE, deckRemaining:room.deck.length, players:[...room.players.values()].map(p=>({id:p.id,name:p.name,isHost:p.isHost,score:p.score,streak:p.streak,robs:p.robs,timeline:orderedTimeline(p)})) };
}
function event(res, name, data) {
  try { res.write(`event: ${name}\ndata: ${JSON.stringify(data)}\n\n`); } catch {}
}
function broadcast(room, name, data) {
  for (const res of room.clients.values()) event(res,name,data);
}
function broadcastState(room) { broadcast(room,'room:update',snapshot(room)); }
function roomOf(code) { return rooms.get(String(code || '').trim().toUpperCase()); }
function getPlayer(room, clientId) { return room.players.get(clientId); }
function timer(room, ms, fn) { clearTimer(room); room.timer = setTimeout(()=>{room.timer=null;fn();},ms); }
function clearTimer(room) { if(room.timer) clearTimeout(room.timer); room.timer=null; }
function validInsertIndex(p, index, year) {
  const tl=orderedTimeline(p); if(!Number.isInteger(index)||index<0||index>tl.length)return false;
  const prev=tl[index-1], next=tl[index]; return (!prev||prev.year<=year)&&(!next||year<=next.year);
}
function placementPoints(streak) { return streak>=5?4:streak>=3?3:2; }
function initialForPlayer(room) { const out=[]; while(out.length<3&&room.deck.length)out.push(songById.get(room.deck.shift())); return out; }

function startGame(room) {
  if(room.players.size<2)throw Error('Necesitas al menos 2 jugadores.');
  if(room.status==='playing')throw Error('La partida ya ha empezado.');
  room.status='playing'; room.round=1; room.turnIndex=0; room.deck=buildDeck(); room.finalRound=false; room.finalRoundStartTurnIndex=null;
  for(const p of room.players.values()){ p.score=0;p.streak=0;p.robs=2;p.timeline=[]; for(const s of initialForPlayer(room))insertCard(p,s); }
  room.playerOrder=[...room.players.keys()]; room.activePlayerId=room.playerOrder[0]; beginTurn(room);
}
function beginTurn(room) {
  clearTimer(room); if(!room.deck.length)room.deck=buildDeck();
  room.currentSongId=room.deck.shift(); room.currentPlacement=null; room.robberId=null; room.phase='turn_listen';
  room.deadlineAt=Date.now()+TURN_MS;
  broadcast(room,'turn:start',{round:room.round,activePlayerId:room.activePlayerId,song:publicSong(songById.get(room.currentSongId)),listenMs:TURN_MS,deadlineAt:room.deadlineAt});
  broadcastState(room); timer(room,TURN_MS,()=>beginPlacement(room));
}
function beginPlacement(room) {
  if(room.status!=='playing')return; room.phase='placement'; room.deadlineAt=Date.now()+THINK_MS;
  broadcast(room,'turn:placement',{activePlayerId:room.activePlayerId,thinkMs:THINK_MS,deadlineAt:room.deadlineAt}); broadcastState(room);
  timer(room,THINK_MS,()=>resolvePlacement(room,null,true));
}
function resolvePlacement(room,index,timedOut=false) {
  if(room.phase!=='placement')return; clearTimer(room);
  const p=getPlayer(room,room.activePlayerId), song=songById.get(room.currentSongId); if(!p||!song)return;
  const correct=!timedOut && validInsertIndex(p,index,song.year);
  if(!correct){
    p.streak=0;room.phase='rob_window';room.deadlineAt=Date.now()+ROB_WINDOW_MS;
    broadcast(room,'turn:failed',{activePlayerId:p.id,timedOut,revealedSong:publicSong(song,true),robWindowMs:ROB_WINDOW_MS,deadlineAt:room.deadlineAt,message:timedOut?'Se acabó el tiempo.':'Colocación incorrecta.'}); broadcastState(room); timer(room,ROB_WINDOW_MS,()=>finishRobWindow(room)); return;
  }
  room.currentPlacement=index; room.phase='bonus'; room.deadlineAt=Date.now()+THINK_MS;
  broadcast(room,'turn:placementResult',{activePlayerId:p.id,correct:true,revealedSong:publicSong(song,true),nextStreak:p.streak+1,bonusMs:THINK_MS,deadlineAt:room.deadlineAt}); broadcastState(room); timer(room,THINK_MS,()=>resolveBonus(room,false,null,null));
}
function resolveBonus(room,gamble,yearGuess,artistGuess) {
  if(room.phase!=='bonus')return; clearTimer(room); const p=getPlayer(room,room.activePlayerId), song=songById.get(room.currentSongId); if(!p||!song)return;
  const nextStreak=p.streak+1; const placePts=placementPoints(nextStreak); let delta=placePts,yearCorrect=false,artistCorrect=false;
  if(gamble){ yearCorrect=Number(yearGuess)===song.year; artistCorrect=normalize(artistGuess)===normalize(song.artist.split(' ft.')[0]); delta += yearCorrect?1:-1; delta += artistCorrect?1:0; }
  p.score+=delta; p.streak=nextStreak; insertCard(p,song); room.phase='reveal';
  broadcastState(room); broadcast(room,'turn:resolved',{playerId:p.id,playerName:p.name,revealedSong:publicSong(song,true),correctPlacement:true,gamble,yearCorrect,artistCorrect,placementPoints:placePts,scoreDelta:delta,score:p.score,streak:p.streak,timeline:orderedTimeline(p)});
  if(p.score>=TARGET_SCORE && !room.finalRound){ room.finalRound=true; room.finalRoundStartTurnIndex=room.turnIndex; broadcast(room,'game:finalRound',{leaderId:p.id,leaderName:p.name,message:'Última ronda: todos los demás tienen un turno para superarle.'}); } timer(room,2800,()=>advanceTurn(room));
}
function startRob(room,clientId){
  if(room.phase!=='rob_window')return false; const p=getPlayer(room,clientId); if(!p||p.id===room.activePlayerId||p.robs<1)return false;
  p.robs--; room.robberId=p.id; room.phase='rob_placement'; room.deadlineAt=Date.now()+ROB_THINK_MS; clearTimer(room);
  broadcast(room,'turn:robStarted',{robberId:p.id,song:publicSong(songById.get(room.currentSongId)),thinkMs:ROB_THINK_MS,deadlineAt:room.deadlineAt}); broadcastState(room); timer(room,ROB_THINK_MS,()=>resolveRob(room,null,true)); return true;
}
function resolveRob(room,index,timedOut=false){
  if(room.phase!=='rob_placement')return; clearTimer(room); const p=getPlayer(room,room.robberId),song=songById.get(room.currentSongId); if(!p||!song)return;
  const correct=!timedOut&&validInsertIndex(p,index,song.year); let delta=0; if(correct){delta=2;p.score+=2;p.streak++;insertCard(p,song);}else p.streak=0;
  room.phase='reveal'; broadcastState(room); broadcast(room,'turn:robResolved',{robberId:p.id,robberName:p.name,correct,scoreDelta:delta,score:p.score,revealedSong:publicSong(song,true),timeline:orderedTimeline(p)});
  if(p.score>=TARGET_SCORE && !room.finalRound){ room.finalRound=true; room.finalRoundStartTurnIndex=room.turnIndex; broadcast(room,'game:finalRound',{leaderId:p.id,leaderName:p.name,message:'Última ronda: todos los demás tienen un turno para superarle.'}); } timer(room,2800,()=>advanceTurn(room));
}
function finishRobWindow(room){if(room.phase!=='rob_window')return;clearTimer(room);room.phase='between_turns';broadcast(room,'turn:robExpired',{revealedSong:publicSong(songById.get(room.currentSongId),true)});timer(room,1200,()=>advanceTurn(room));}
function advanceTurn(room){if(room.status!=='playing')return;room.turnIndex=(room.turnIndex+1)%room.playerOrder.length;if(room.finalRound && room.turnIndex===room.finalRoundStartTurnIndex){return finishGame(room,null);}room.activePlayerId=room.playerOrder[room.turnIndex];room.round++;beginTurn(room);}
function finishGame(room,winnerId){clearTimer(room);room.status='finished';room.phase='game_over';const ranking=[...room.players.values()].map(p=>({id:p.id,name:p.name,score:p.score})).sort((a,b)=>b.score-a.score);const winner=winnerId?ranking.find(p=>p.id===winnerId):ranking[0];broadcast(room,'game:over',{winnerId:winner?.id||null,ranking});broadcastState(room);}

function sendJson(res,status,obj){const body=JSON.stringify(obj);res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','Access-Control-Allow-Origin':'*'});res.end(body);}
async function readJson(req){let data='';for await(const chunk of req)data+=chunk;return data?JSON.parse(data):{};}
function staticFile(req,res,urlPath){let filePath=urlPath==='/'?path.join(PUBLIC,'index.html'):path.join(PUBLIC,urlPath.replace(/^\//,''));if(!filePath.startsWith(PUBLIC))return sendJson(res,403,{error:'forbidden'});fs.stat(filePath,(err,st)=>{if(err||!st.isFile())return sendJson(res,404,{error:'not found'});const ext=path.extname(filePath);const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.ico':'image/x-icon'};res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream'});fs.createReadStream(filePath).pipe(res);});}

const server=http.createServer(async(req,res)=>{
  try{
    const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
    if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Allow-Headers':'Content-Type'});return res.end();}
    if(req.method==='GET'&&url.pathname==='/health')return sendJson(res,200,{ok:true,rooms:rooms.size,songs:songs.length});
    if(req.method==='GET'&&url.pathname==='/events'){
      const code=url.searchParams.get('room'),clientId=url.searchParams.get('client');const room=roomOf(code);if(!room||!clientId||!room.players.has(clientId))return sendJson(res,404,{error:'Sala o jugador no encontrado.'});
      res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache, no-transform','Connection':'keep-alive','X-Accel-Buffering':'no'});res.write(`retry: 1000\n\n`);room.clients.set(clientId,res);event(res,'room:update',snapshot(room));req.on('close',()=>{if(room.clients.get(clientId)===res)room.clients.delete(clientId);});return;
    }
    if(req.method==='POST'){
      const body=await readJson(req);
      if(url.pathname==='/api/create'){
        const name=cleanName(body.name);if(!name)return sendJson(res,400,{ok:false,error:'Escribe un nombre.'});const code=roomCode(),client=id();const room={code,hostId:client,players:new Map([[client,player(client,name,true)]]),playerOrder:[client],clients:new Map(),status:'lobby',phase:'lobby',round:0,turnIndex:0,activePlayerId:null,deck:[],currentSongId:null,currentPlacement:null,robberId:null,timer:null,deadlineAt:null,finalRound:false,finalRoundStartTurnIndex:null};rooms.set(code,room);return sendJson(res,200,{ok:true,code,clientId:client});
      }
      if(url.pathname==='/api/join'){
        const code=String(body.code||'').trim().toUpperCase(),name=cleanName(body.name),room=roomOf(code);if(!room)return sendJson(res,404,{ok:false,error:'No existe esa sala.'});if(room.status!=='lobby')return sendJson(res,400,{ok:false,error:'La partida ya ha empezado.'});if(room.players.size>=8)return sendJson(res,400,{ok:false,error:'La sala está llena.'});if(!name)return sendJson(res,400,{ok:false,error:'Escribe un nombre.'});if([...room.players.values()].some(p=>p.name.toLowerCase()===name.toLowerCase()))return sendJson(res,400,{ok:false,error:'Ese nombre ya está en uso.'});const client=id();room.players.set(client,player(client,name,false));room.playerOrder.push(client);broadcastState(room);return sendJson(res,200,{ok:true,code,clientId:client});
      }
      const code=String(body.code||'').toUpperCase(),clientId=String(body.clientId||'');const room=roomOf(code);if(!room)return sendJson(res,404,{ok:false,error:'Sala no encontrada.'});
      if(url.pathname==='/api/start'){if(room.hostId!==clientId)return sendJson(res,403,{ok:false,error:'Solo el creador puede empezar.'});try{startGame(room);return sendJson(res,200,{ok:true});}catch(e){return sendJson(res,400,{ok:false,error:e.message});}}
      if(url.pathname==='/api/place'){if(room.phase!=='placement'||room.activePlayerId!==clientId)return sendJson(res,400,{ok:false,error:'No puedes colocar ahora.'});const index=Number(body.index);resolvePlacement(room,index,false);return sendJson(res,200,{ok:true});}
      if(url.pathname==='/api/bonus'){if(room.phase!=='bonus'||room.activePlayerId!==clientId)return sendJson(res,400,{ok:false,error:'No puedes responder ahora.'});resolveBonus(room,Boolean(body.gamble),body.yearGuess,body.artistGuess);return sendJson(res,200,{ok:true});}
      if(url.pathname==='/api/rob'){const ok=startRob(room,clientId);return sendJson(res,ok?200:400,{ok,error:ok?undefined:'No puedes robar esta canción.'});}
      if(url.pathname==='/api/rob-place'){if(room.phase!=='rob_placement'||room.robberId!==clientId)return sendJson(res,400,{ok:false,error:'No puedes jugar el robo.'});resolveRob(room,Number(body.index),false);return sendJson(res,200,{ok:true});}
      if(url.pathname==='/api/restart'){if(room.hostId!==clientId)return sendJson(res,403,{ok:false,error:'Solo el creador puede reiniciar.'});clearTimer(room);room.status='lobby';room.phase='lobby';room.round=0;room.turnIndex=0;room.activePlayerId=null;room.deck=[];room.currentSongId=null;room.currentPlacement=null;room.robberId=null;room.finalRound=false;room.finalRoundStartTurnIndex=null;for(const p of room.players.values()){p.score=0;p.streak=0;p.robs=2;p.timeline=[];}broadcastState(room);return sendJson(res,200,{ok:true});}
      return sendJson(res,404,{error:'not found'});
    }
    if(req.method==='GET')return staticFile(req,res,url.pathname);
    return sendJson(res,405,{error:'method not allowed'});
  }catch(e){console.error(e);if(!res.headersSent)sendJson(res,500,{ok:false,error:'Error interno del servidor.'});}
});

server.listen(PORT,HOST,()=>console.log(`CRONOS activo en http://localhost:${PORT}`));
