# CRONOS — modo clásico

MVP jugable online de un juego musical por línea temporal.

## Requisitos

- Node.js 20+
- Navegador moderno
- Conexión a Internet (los clips se reproducen mediante YouTube Embeds)

## Arrancar

```bash
npm install
npm start
```

Abre:

http://localhost:3000

Para jugar desde casas distintas, el servidor debe desplegarse en un hosting público con WebSockets/Socket.IO. El mismo proyecto está preparado para ello.

## Controles del juego

- 2–8 jugadores.
- Sala privada mediante código de 5 caracteres.
- 3 canciones iniciales por jugador.
- Turno de 25 s para escuchar y 15 s para colocar.
- Colocación correcta: 2, 3 o 4 puntos según racha.
- Bonus opcional: +1 por año exacto y +1 por artista; cada error de bonus resta 1.
- 2 robos por jugador. Un robo correcto da 2 puntos.
- Objetivo: 20 puntos y una última ronda implícita mediante el estado del juego.

## Canciones

`data/songs.json` contiene un catálogo inicial pequeño para probar el juego. Cada entrada usa un ID de vídeo de YouTube y un segundo inicial.

Para una edición real, conviene ampliar este catálogo y verificar individualmente qué vídeos admiten reproducción embebida y siguen disponibles. La aplicación no descarga ni almacena audio.

## Arquitectura

- `server.js`: Express + Socket.IO, autoridad de sala, turnos, puntuación, robos y validación.
- `public/index.html`: interfaz.
- `public/styles.css`: diseño responsive.
- `public/app.js`: cliente, temporizadores y YouTube IFrame Player API.

## Siguiente iteración recomendada

1. Admin para importar/validar canciones.
2. Biblioteca de cientos/miles de canciones.
3. Sincronización de inicio de los clips y detección de pausas.
4. Mejoras visuales/sonoras y animaciones.
5. Despliegue con dominio propio.

## Despliegue

El servidor usa únicamente módulos incorporados de Node.js: no hace falta `npm install`.

En un hosting que ejecute Node, basta con arrancar:

```bash
npm start
```

El script escucha en `PORT` y en `0.0.0.0`, por lo que es apto para plataformas de despliegue que asignen el puerto mediante variable de entorno.

YouTube recomienda usar la IFrame Player API para controlar los vídeos embebidos y avisar de casos de autoplay bloqueado. La aplicación deja un botón explícito de reproducción para evitar depender del autoplay del navegador.
